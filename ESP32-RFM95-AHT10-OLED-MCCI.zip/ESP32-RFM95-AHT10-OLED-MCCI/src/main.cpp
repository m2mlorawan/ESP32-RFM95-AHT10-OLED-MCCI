#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h>
#include <CayenneLPP.h>
#include <Adafruit_AHTX0.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
//#include <Fonts/FreeMonoBold9pt7b.h> 

Adafruit_AHTX0 aht;
float temp,hum;

#define SCREEN_HEIGHT 64 
#define SCREEN_WIDTH 128 

CayenneLPP lpp(51); // create a buffer of 51 bytes to store the payload
//#define ABP
#define OTA
#define LED_PIN 2
// show debug statements; comment next line to disable debug statements
float slptime = 1;

int cnt = 1;

#define OLED_RESET     -1 
Adafruit_SSD1306 OLED(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

int var = 0; 

//  OTAA Keys
//  The 2 below should be in little endian format (lsb)
static const uint8_t PROGMEM APPEUI[8] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static const uint8_t PROGMEM DEVEUI[8] = { 0x00, 0x3F, 0x70, 0xDD, 0xBB, 0xDA, 0x8F, 0xAA };
// This should be in big endian format (msb)
static const uint8_t PROGMEM APPKEY[16] = {0xDA, 0x5A, 0x42, 0xB8, 0x71, 0x50, 0x2E, 0xBA, 0x68, 0x38, 0xC5, 0x28, 0xDE, 0x07, 0xC2, 0xAA};

// ABP Keys
static const uint8_t PROGMEM NWKSKEY[16] = {0xA6, 0xC3, 0x0F, 0xB2, 0x91, 0xDB, 0x55, 0xC5, 0x31, 0x82, 0x53, 0xD4, 0x08, 0x08, 0x7A, 0xAA};
static const uint8_t PROGMEM APPSKEY[16] = {0x54, 0xBE, 0x2D, 0xE6, 0xB6, 0xB3, 0xF7, 0xC2, 0xD0, 0x33, 0x72, 0xB5, 0x27, 0x20, 0xD6, 0xAA};
static const uint32_t DEVADDR = 0x260115AA;

#ifdef OTA
void os_getArtEui(u1_t *buf)
{
  memcpy_P(buf, APPEUI, 8);
}
void os_getDevEui(u1_t *buf) { memcpy_P(buf, DEVEUI, 8); }
void os_getDevKey(u1_t *buf) { memcpy_P(buf, APPKEY, 16); }
#else
void os_getArtEui(u1_t *buf)
{
}
void os_getDevEui(u1_t *buf) {}
void os_getDevKey(u1_t *buf) {}
#endif

static osjob_t sendjob;
// Schedule TX every this many seconds (might become longer due to duty cycle limitations).
const unsigned TX_INTERVAL = .1;

const lmic_pinmap lmic_pins = {
    .nss = 5,
    .rxtx = LMIC_UNUSED_PIN,
    .rst = LMIC_UNUSED_PIN,
    .dio = {12, 14, 27},
};

void do_send(osjob_t *j)
{
  // Check if there is not a current TX/RX job running
  if (LMIC.opmode & OP_TXRXPEND)
  {
    Serial.println(F("OP_TXRXPEND, not sending"));
  }
  else
  {
    // Prepare upstream data transmission at the next possible time.

  sensors_event_t tempEvent;
  sensors_event_t humidityEvent;
  aht.getEvent(&humidityEvent, &tempEvent);
  temp = tempEvent.temperature;
  hum = humidityEvent.relative_humidity;

    Serial.print("Temp:");
    Serial.print(temp);
    Serial.println(" C");

    Serial.print("Humd:");
    Serial.print(hum);
    Serial.println(" %");

    //OLED.clearDisplay();
    OLED.setTextSize(2);
    OLED.setCursor(0, 13);
    OLED.printf("T %.2f", temp);
    OLED.setCursor(0, 32);
    OLED.printf("H %.2f", hum);
    OLED.display();

    lpp.reset(); // clear the buffer
    lpp.addTemperature(2, temp);
    lpp.addRelativeHumidity(3, hum);

    LMIC_setTxData2(1, lpp.getBuffer(), lpp.getSize(), 0);
    Serial.println(F("Packet queued"));
    digitalWrite(LED_PIN,HIGH);
    delay(500);
    digitalWrite(LED_PIN,LOW);
  }
  // Next TX is scheduled after TX_COMPLETE event.
}

void onEvent(ev_t ev)
{
  Serial.print(os_getTime());
  Serial.print(": ");
  //Serial.print(ev);
  switch (ev)
  {
  case EV_SCAN_TIMEOUT:
    Serial.println(F("EV_SCAN_TIMEOUT"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_SCAN_TIMEOUT");
    OLED.display();
    break;
  case EV_BEACON_FOUND:
    Serial.println(F("EV_BEACON_FOUND"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_BEACON_FOUND");
    OLED.display();
    break;
  case EV_BEACON_MISSED:
    Serial.println(F("EV_BEACON_MISSED"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_BEACON_MISSED");
    OLED.display();
    break;
  case EV_BEACON_TRACKED:
    Serial.println(F("EV_BEACON_TRACKED"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_BEACON_TRACKED");
    OLED.display();
    break;
  case EV_JOINING:
    Serial.println(F("EV_JOINING"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_JOINING");
    OLED.display();
    break;
  case EV_JOINED:
    Serial.println(F("EV_JOINED"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_JOINED");
    OLED.display();
    delay (6000);
    // Disable link check validation (automatically enabled
    // during join, but not supported by TTN at this time).
    LMIC_setLinkCheckMode(0);
    break;
  case EV_RFU1:
    Serial.println(F("EV_RFU1"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_RFU1");
    OLED.display();
    break;
  case EV_JOIN_FAILED:
    Serial.println(F("EV_JOIN_FAILED"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_JOIN_FAILED");
    OLED.display();
    break;
  case EV_REJOIN_FAILED:
    Serial.println(F("EV_REJOIN_FAILED"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_REJOIN_FAILED");
    OLED.display();
    break;
  
  case EV_TXCOMPLETE:
    Serial.println(F("EV_TXCOMPLETE (includes waiting for RX windows)"));
    Serial.println();
    Serial.println("=============");
    Serial.print("PACKET#");
    Serial.println(cnt);
    Serial.println("=============");
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.println("EV_TXCOMPLETE");
    OLED.setCursor(0, 0);
    OLED.printf("PACKET# %i",cnt);
    OLED.display();
    cnt = cnt + 1;
    if (LMIC.txrxFlags & TXRX_ACK)
      Serial.println(F("Received ack"));
    if (LMIC.dataLen)
    {
      // data received in rx slot after tx
      Serial.print(F("Received "));
      Serial.print(LMIC.dataLen);
      Serial.print(F(" bytes for downlink: 0x"));
      for (int i = 0; i < LMIC.dataLen; i++)
      {
        if (LMIC.frame[LMIC.dataBeg + i] < 0x10)
        {
          Serial.print(F("0"));
        }
        Serial.print(LMIC.frame[LMIC.dataBeg + i], HEX);
      }
      Serial.println();
    }

    //delay(slptime);
    // Schedule next transmission
    os_setTimedCallback(&sendjob, os_getTime() + sec2osticks(TX_INTERVAL), do_send);
    break;
  case EV_LOST_TSYNC:
    Serial.println(F("EV_LOST_TSYNC"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_LOST_TSYNC");
    OLED.display();
    break;
  case EV_RESET:
    Serial.println(F("EV_RESET"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_RESET");
    OLED.display();
    break;
  case EV_RXCOMPLETE:
    // data received in ping slot
    Serial.println(F("EV_RXCOMPLETE"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_RXCOMPLETE");
    OLED.display();
    break;
  case EV_LINK_DEAD:
    Serial.println(F("EV_LINK_DEAD"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_LINK_DEAD");
    OLED.display();
    break;
  case EV_LINK_ALIVE:
    Serial.println(F("EV_LINK_ALIVE"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("EV_LINK_ALIVE");
    OLED.display();
    break;
  case EV_TXSTART:
    Serial.println(F("EV_TXSTART"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.println("EV_TXSTART   ");
    OLED.display();
    break;
  default:
    Serial.println(F("Unknown event"));
    OLED.setCursor(0, 50);
    OLED.setTextSize(1);
    OLED.clearDisplay();
    OLED.println("Unknown event");
    OLED.display();
    break;
  }
}

void setup()
{
  Wire.begin();
  //delay(2500); // Give time to the ATMega32u4 port to wake up and be recognized by the OS.
  Serial.begin(115200);
  pinMode(LED_PIN,OUTPUT);

  if (!OLED.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println("SSD1306 allocation failed");
  } else {
    Serial.println("OLED Start Work !!!");
    OLED.clearDisplay();   
    OLED.display(); 
  }

  if (! aht.begin()) {
    Serial.println("Could not find AHT? Check wiring");
    while (1) delay(10);
  }
  Serial.println("AHT10 or AHT20 found");

  // LMIC init
  os_init();

  // Reset the MAC state. Session and pending data transfers will be discarded.
  LMIC_reset();

#ifdef ABP
// Set static session parameters. Instead of dynamically establishing a session
// by joining the network, precomputed session parameters are be provided.
#ifdef PROGMEM
  // On AVR, these values are stored in flash and only copied to RAM
  // once. Copy them to a temporary buffer here, LMIC_setSession will
  // copy them into a buffer of its own again.
  uint8_t appskey[sizeof(APPSKEY)];
  uint8_t nwkskey[sizeof(NWKSKEY)];

  memcpy_P(appskey, APPSKEY, sizeof(APPSKEY));
  memcpy_P(nwkskey, NWKSKEY, sizeof(NWKSKEY));
  LMIC_setSession(0x1, DEVADDR, nwkskey, appskey);
#else
  // If not running an AVR with PROGMEM, just use the arrays directly
  LMIC_setSession(0x1, DEVADDR, NWKSKEY, APPSKEY);
#endif

#endif

  // Enable link check validation
  LMIC_setLinkCheckMode(0);
  // Enable data rate adaptation
  // LMIC_setAdrMode(1);
  LMIC_setAdrMode(0);
  // Allow small clock errors
  LMIC_setClockError(MAX_CLOCK_ERROR * 10 / 100);

  LMIC.dn2Dr = DR_SF10;

  // Set data rate and transmit power for uplink (note: txpow seems to be ignored by the library)
  //  LMIC_setDrTxpow(DR_SF9, 14);
  LMIC_setDrTxpow(DR_SF7, 14);

  // Start job
  do_send(&sendjob);
  //delay (slptime);

  //OLED.setFont(&FreeMonoBold9pt7b);
  OLED.display();
  OLED.clearDisplay(); 
  OLED.setTextColor(WHITE, BLACK);  
  OLED.setCursor(0, 0); 
  OLED.setTextSize(2); 
  OLED.println("LoRaWAN"); 
  OLED.setCursor(0, 25);
  OLED.println("Thailand");
  OLED.display(); 
  delay (1000);
  OLED.clearDisplay();

}

void loop()
{
  os_runloop_once();
}
